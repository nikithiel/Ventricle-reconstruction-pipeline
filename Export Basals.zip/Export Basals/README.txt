Basic = ohne shrinkwrap ohne moving
Small Smoothing = Mit Shrinkwrap und mit kleines Smoothing 0.5 x 5
Big Smoothing = Mit Shrinkwrap und mit starkes Smoothing 0.5 x 50